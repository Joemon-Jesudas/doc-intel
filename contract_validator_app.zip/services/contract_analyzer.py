
import json
import os
import time

class ContractAnalyzer:
    def __init__(self, client):
        self.client = client
        self.model = os.getenv("AZURE_OPENAI_MODEL")

    def analyze(self, text: str):
        with open("prompt_template.txt") as f:
            system_prompt = f.read()

        start = time.time()
        response = self.client.chat.completions.create(
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Analyze this contract:\n\n{text}"}
            ],
            model=self.model,
            max_tokens=4096,
            response_format={"type": "json_object"}
        )

        data = json.loads(response.choices[0].message.content)
        return data, time.time() - start


import time

class DocumentExtractor:
    def __init__(self, client):
        self.client = client

    def extract_text(self, pdf_bytes: bytes):
        start = time.time()
        poller = self.client.begin_analyze_document(
            model_id="prebuilt-layout",
            body=pdf_bytes
        )
        result = poller.result()

        full_text = "\n".join(
            line.content for page in result.pages for line in page.lines
        )

        return full_text, len(result.pages), time.time() - start
